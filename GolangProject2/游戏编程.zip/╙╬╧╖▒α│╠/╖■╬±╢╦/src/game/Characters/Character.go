package Characters

type Character struct {
	Name     string
	Rotation [3]float32
	Point    [3]float32
	Health   int

}