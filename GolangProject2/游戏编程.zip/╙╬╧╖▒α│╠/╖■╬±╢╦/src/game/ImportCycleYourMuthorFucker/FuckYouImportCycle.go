package ImportCycleYourMuthorFucker

import (
	"ace"
	"game/Characters"
)

func SpawnMonster(session *ace.Session){
	Characters.SpawnMonster(session)
}
