// Protocol
package protocol

const (
	LOGIN = 1
	MAP   = 2
)
